<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>View File</title>
	<link rel="stylesheet" href="">
</head>
<body>

	<ol>
		<li>Assignment<a href="web/viewer.html?file=assignment" title=""> open</a></li>
		<li>How vocabulary should be learned<a href="web/viewer.html?file=How-vocabulary-should-be-learned.pdf" title=""> open</a></li>
		<li>Sustainable Tourism Development case study Ochheuteal Beach<a href="web/viewer.html?file=Sustainable Tourism Development case study Ochheuteal Beach" title=""> open</a></li>
	</ol>
	
</body>
</html>